/**
 * Module Description: Product Catalog & Category Workspace Controller
 * Manages category tab navigation, adaptive square product card rendering
 * (detecting and filtering out placeholder SVGs so items without custom photos
 * expand into full-box text tiles), multi-criteria sorting (Name A-Z/Z-A,
 * Price Low/High, Date Created Newest/Oldest), real-time inventory warnings
 * (low-stock badges and out-of-stock overlays), quick-access add-on shelf,
 * hardware barcode scanning input, and reactive cart additions.
 */

import { DB } from "./db.js";
import { Cart } from "./cart.js";
import { Bus } from "./bus.js";

// Safe Base64-encoded SVG fallback
const FALLBACK_IMG = "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0iIzk0YTNiOCI+PHBhdGggZD0iTTIxIDE5VjVjMC0xLjEtLjktMi0yLTJINWMtMS4xIDAtMiAuOS0yIDJ2MTRjMCAxLjEuOSAyIDIgMmgxNGMxLjEgMCAyLS45IDItMnpNOC41IDEzLjVsMi41IDMuMDFMMTQuNSAxMmw0LjUgNkg1bDMuNS00LjV6Ii8+PC9zdmc+";

/**
 * Validates whether an image property represents a genuine user photo
 * rather than an empty value or an internal SVG fallback placeholder.
 * @param {any} img
 * @returns {boolean}
 */
function isValidProductImage(img) {
  if (!img || typeof img !== "string") return false;
  const clean = img.trim();
  if (clean === "" || clean === FALLBACK_IMG) return false;
  if (clean.includes("<svg") || clean.includes("PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmci")) {
    return false;
  }
  return true;
}

export const CatalogUI = {
  currentCategory: "all",
  currentSort: localStorage.getItem("pos_catalog_sort") || "default",
  elements: {},
  initialized: false,

  /**
   * Initializes DOM bindings, sort selector events, scanner listeners, and inventory subscriptions
   */
  init() {
    this.elements = {
      categoryTabs: document.getElementById("category-tabs"),
      productGrid: document.getElementById("product-grid"),
      barcodeInput: document.getElementById("barcode-input"),
      catalogSortSelect: document.getElementById("catalog-sort-select"),
      catalogActiveCategoryTitle: document.getElementById("catalog-active-category-title"),
      quickMenuContainer: document.getElementById("quick-menu-container"),
      quickMenuScroll: document.getElementById("quick-menu-scroll")
    };

    // Initialize sort dropdown selection from persistent local storage
    if (this.elements.catalogSortSelect) {
      this.elements.catalogSortSelect.value = this.currentSort;
      this.elements.catalogSortSelect.onchange = async () => {
        this.currentSort = this.elements.catalogSortSelect.value || "default";
        localStorage.setItem("pos_catalog_sort", this.currentSort);
        await this.loadProducts(this.currentCategory);
      };
    }

    // Category sidebar delegation
    if (this.elements.categoryTabs) {
      this.elements.categoryTabs.onclick = async (e) => {
        const pill = e.target.closest(".cat-pill");
        if (!pill || !pill.dataset.cat) return;

        this.elements.categoryTabs.querySelectorAll(".cat-pill").forEach((p) => {
          p.classList.remove("active");
        });
        pill.classList.add("active");
        await this.loadProducts(pill.dataset.cat);
      };
    }

    // Delegated click handler on product grid
    if (this.elements.productGrid) {
      this.elements.productGrid.onclick = async (e) => {
        const card = e.target.closest(".product-card");
        if (!card || !card.dataset.id) return;

        const match = await DB.getProductById(card.dataset.id);
        if (!match) return;

        if (match.isMonitored && match.stock <= 0) {
          alert(`"${match.name}" is OUT OF STOCK.`);
          return;
        }

        if (!match.isMonitored && match.isAvailable === false) {
          alert(`"${match.name}" is currently unavailable.`);
          return;
        }

        const res = Cart.add(match);
        if (!res.ok && res.reason === "stock_exceeded") {
          alert(`Cannot add more "${match.name}": Only ${res.available} unit(s) available in stock.`);
        }
      };
    }

    // Delegated click handler on Quick Menu shelf
    if (this.elements.quickMenuScroll) {
      this.elements.quickMenuScroll.onclick = async (e) => {
        const btn = e.target.closest(".quick-card");
        if (!btn || !btn.dataset.id) return;

        const match = await DB.getProductById(btn.dataset.id);
        if (!match) return;

        if (match.isMonitored && match.stock <= 0) {
          alert(`"${match.name}" is OUT OF STOCK.`);
          return;
        }

        if (!match.isMonitored && match.isAvailable === false) {
          alert(`"${match.name}" is currently unavailable.`);
          return;
        }

        const res = Cart.add(match);
        if (!res.ok && res.reason === "stock_exceeded") {
          alert(`Cannot add more "${match.name}": Only ${res.available} unit(s) available in stock.`);
        }
      };
    }

    // Hardware barcode scanner listener (Enter-terminated string)
    if (this.elements.barcodeInput) {
      this.elements.barcodeInput.onkeydown = async (e) => {
        if (e.key === "Enter") {
          const code = this.elements.barcodeInput.value.trim();
          if (code) {
            const match = await DB.getProductByBarcode(code);
            if (match) {
              const res = Cart.add(match);
              if (!res.ok) {
                if (res.reason === "out_of_stock") {
                  alert(`Cannot add "${match.name}": Item is OUT OF STOCK.`);
                } else if (res.reason === "stock_exceeded") {
                  alert(`Cannot add more "${match.name}": Only ${res.available} unit(s) available in stock.`);
                } else if (res.reason === "unavailable") {
                  alert(`"${match.name}" is currently marked as UNAVAILABLE.`);
                }
              }
            } else {
              console.warn(`[Scanner] Barcode not found in catalog: ${code}`);
            }
          }
          this.elements.barcodeInput.value = "";
        }
      };
    }

    if (this.initialized) return;
    this.initialized = true;

    // Bus event listeners for inventory alerts and catalog updates
    Bus.on("cart:stock-limit-reached", (data) => {
      alert(`Stock Limit Reached: "${data.product.name}" only has ${data.available} unit(s) remaining.`);
    });

    Bus.on("cart:out-of-stock", (data) => {
      alert(`"${data.product.name}" is currently out of stock.`);
    });

    Bus.on("cart:item-unavailable", (data) => {
      alert(`"${data.product.name}" is currently marked as unavailable for sale.`);
    });

    Bus.on("sync:completed", async () => {
      await this.loadProducts(this.currentCategory);
      await this.loadQuickMenu();
    });

    Bus.on("inventory:updated", async () => {
      await this.loadProducts(this.currentCategory);
      await this.loadQuickMenu();
    });

    Bus.on("catalog:addons-updated", async () => {
      await this.loadQuickMenu();
    });
  },

  /**
   * Loads category list from IndexedDB and populates category sidebar
   */
  async loadCategories() {
    if (!this.elements.categoryTabs) return;

    const categories = await DB.getCategories();
    this.elements.categoryTabs.innerHTML = categories.map((cat) => {
      const hasImage = isValidProductImage(cat.image);
      const pillClass = `cat-pill ${cat.id === this.currentCategory ? "active" : ""} ${hasImage ? "has-img" : "text-only"}`;

      const imgHtml = hasImage
        ? `
          <div class="cat-img-wrap">
            <img 
              src="${cat.image}" 
              alt="${cat.name}" 
              loading="lazy" 
              onerror="this.onerror=null;const p=this.closest('.cat-pill');if(p){p.classList.remove('has-img');p.classList.add('text-only');}this.parentElement.remove();" 
            />
          </div>
        `
        : "";

      return `
        <button type="button" class="${pillClass}" data-cat="${cat.id}">
          ${imgHtml}
          <span class="cat-label">${cat.name}</span>
        </button>
      `;
    }).join("");
  },

  /**
   * Sorts product array in memory based on current active sort setting
   * @param {Array<Object>} products
   * @returns {Array<Object>}
   */
  applyProductSorting(products) {
    if (!Array.isArray(products) || products.length <= 1) return products;

    return [...products].sort((a, b) => {
      switch (this.currentSort) {
        case "name-asc":
          return (a.name || "").localeCompare(b.name || "", undefined, { numeric: true, sensitivity: "base" });
        case "name-desc":
          return (b.name || "").localeCompare(a.name || "", undefined, { numeric: true, sensitivity: "base" });
        case "price-asc":
          return (Number(a.price) || 0) - (Number(b.price) || 0);
        case "price-desc":
          return (Number(b.price) || 0) - (Number(a.price) || 0);
        case "date-desc": {
          const tA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
          const tB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
          return tB - tA;
        }
        case "date-asc": {
          const tA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
          const tB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
          return tA - tB;
        }
        case "default":
        default:
          return 0;
      }
    });
  },

  /**
   * Loads products filtered by category, applies sorting, and renders cards.
   * Dynamically ignores fallback SVG placeholders and triggers full-box text rendering.
   * @param {string} categoryId
   */
  async loadProducts(categoryId = "all") {
    if (!this.elements.productGrid) return;

    this.currentCategory = categoryId;
    const rawProducts = await DB.getProducts(categoryId);
    const sortedProducts = this.applyProductSorting(rawProducts);
    const generalThreshold = parseInt(localStorage.getItem("pos_general_low_stock_threshold") || "5", 10);

    // Update active category title in workspace header bar
    if (this.elements.catalogActiveCategoryTitle) {
      if (categoryId === "all") {
        this.elements.catalogActiveCategoryTitle.textContent = "All Items";
      } else {
        const catObj = await DB.getCategoryById(categoryId);
        this.elements.catalogActiveCategoryTitle.textContent = catObj ? catObj.name : "Products";
      }
    }

    if (sortedProducts.length === 0) {
      this.elements.productGrid.innerHTML = `
        <div class="empty-catalog-message">
          <span>No products found in this category.</span>
        </div>
      `;
      return;
    }

    this.elements.productGrid.innerHTML = sortedProducts.map((prod) => {
      const isMon = Boolean(prod.isMonitored);
      let badgeHtml = "";
      let overlayHtml = "";
      let cardClasses = "product-card";

      if (isMon) {
        const stock = typeof prod.stock === "number" ? prod.stock : 0;
        const effThreshold = (prod.threshold !== null && prod.threshold !== undefined && prod.threshold !== "")
          ? parseInt(prod.threshold, 10)
          : generalThreshold;

        if (stock <= 0) {
          cardClasses += " out-of-stock";
          overlayHtml = `<div class="card-depleted-overlay"><span>OUT OF STOCK</span></div>`;
        } else if (stock <= effThreshold) {
          badgeHtml = `<div class="card-stock-badge badge-low-stock">⚠️ LOW: ${stock}</div>`;
        } else {
          badgeHtml = `<div class="card-stock-badge badge-stock-count">${stock} in stock</div>`;
        }
      } else {
        if (prod.isAvailable === false) {
          cardClasses += " unavailable";
          overlayHtml = `<div class="card-depleted-overlay overlay-unavail"><span>UNAVAILABLE</span></div>`;
        }
      }

      // Detect if product has a genuine image asset, ignoring SVG fallback placeholders
      const hasImage = isValidProductImage(prod.image);
      cardClasses += hasImage ? " has-image" : " text-only-card";

      const imgBlock = hasImage
        ? `
          <div class="prod-img-wrap">
            <img 
              class="prod-img" 
              src="${prod.image}" 
              alt="${prod.name}" 
              loading="lazy" 
              onerror="this.onerror=null;const card=this.closest('.product-card');if(card){card.classList.remove('has-image');card.classList.add('text-only-card');}this.parentElement.remove();" 
            />
          </div>
        `
        : "";

      return `
        <div class="${cardClasses}" data-id="${prod.id}">
          ${badgeHtml}
          ${overlayHtml}
          ${imgBlock}
          <div class="prod-info">
            <span class="prod-title">${prod.name}</span>
            <div class="price">₱${Number(prod.price).toFixed(2)}</div>
          </div>
        </div>
      `;
    }).join("");
  },

  /**
   * Loads and renders Add-on category products into the horizontal Quick Menu shelf
   */
  async loadQuickMenu() {
    if (!this.elements.quickMenuScroll || !this.elements.quickMenuContainer) return;

    const addonProducts = await DB.getAddonProducts();

    if (addonProducts.length === 0) {
      this.elements.quickMenuContainer.classList.add("hidden");
      this.elements.quickMenuScroll.innerHTML = "";
      return;
    }

    this.elements.quickMenuContainer.classList.remove("hidden");

    this.elements.quickMenuScroll.innerHTML = addonProducts.map((item) => {
      const isMon = Boolean(item.isMonitored);
      let disabledClass = "";
      let stockHint = "";

      if (isMon) {
        const stock = typeof item.stock === "number" ? item.stock : 0;
        if (stock <= 0) {
          disabledClass = " out-of-stock";
          stockHint = `<span class="quick-card-stock out">Out</span>`;
        } else {
          stockHint = `<span class="quick-card-stock">${stock} left</span>`;
        }
      } else if (item.isAvailable === false) {
        disabledClass = " unavailable";
        stockHint = `<span class="quick-card-stock out">Unavail</span>`;
      }

      const hasImage = isValidProductImage(item.image);
      const quickClasses = `quick-card${disabledClass}${hasImage ? "" : " text-only-quick"}`;

      const thumbHtml = hasImage
        ? `
          <div class="quick-card-thumb">
            <img 
              src="${item.image}" 
              alt="${item.name}" 
              loading="lazy" 
              onerror="this.onerror=null;const q=this.closest('.quick-card');if(q){q.classList.add('text-only-quick');}this.parentElement.remove();" 
            />
          </div>
        `
        : "";

      return `
        <button type="button" class="${quickClasses}" data-id="${item.id}" title="Quick Add: ${item.name}">
          ${thumbHtml}
          <div class="quick-card-details">
            <span class="quick-card-title">${item.name}</span>
            <div class="quick-card-meta">
              <span class="quick-card-price">₱${Number(item.price).toFixed(2)}</span>
              ${stockHint}
            </div>
          </div>
        </button>
      `;
    }).join("");
  },

  /**
   * Focuses the barcode input field for immediate scanning
   */
  focusBarcode() {
    if (this.elements.barcodeInput) {
      this.elements.barcodeInput.focus();
    }
  },

  /**
   * Returns current active category ID
   * @returns {string}
   */
  getActiveCategory() {
    return this.currentCategory;
  }
};

// REMARK: CATALOG_UI_JS_FILTER_PLACEHOLDER_SVGS_COMPLETE